import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dados.dart';
import 'dart:async';

bool valido(String valor) {
  return valor.isEmpty ? false : true;
}

//Faz requisição de dados
Future<String> getDadosProativaGo(
    {String url,
    String operacao,
    String reqStr, //Tem prioridade sobre mapaReq
    Map<String, dynamic> mapaReq = const {}}) async {
  // ignore: unnecessary_statements
  url ?? Url;
  print('o oper ====== $operacao');
  operacao = (operacao == null) ? "LOGIN" : operacao;
  print('o oper ====== $operacao');
  String Requis = "";
  //req??"&usuario=$login&senha=$senha&so=$so&modelo=$modelo";
  print("aqui1");
  if (reqStr == null) {
    //if(mapa.isEmpty)domapa="Veio sem nada nem poha nenhuma";else
    //   mapa.forEach((k,v){domapa +="&$k=$v";});
    if (mapaReq.isEmpty) {
      Requis = "&usuario=$login&senha=$senha&so=$so&modelo=$modelo";
      print("aqui2: $reqStr <<<<<<<");
    } else {
      print("aqui3");
      //mapa.forEach((k,v){domapa +="&$k=$v";});
      mapaReq.forEach((k, v) => Requis += "&$k=$v");
      print("aqui2: $Requis <<<<<<<");}
  } else {
    Requis = reqStr;
  }

  print('Requisições: $operacao$Requis');

  /* http.Response response = await http.get("${Url}?op=LOGIN&usuario=$login&senha=$senha"
      "&so=$so&modelo=$modelo");*/
  print("VAI CHAMAR ISSO: ${Url}?op=$operacao$Requis");
  print(
      "QUE DEVERIA SER: $Url?op=LOGIN&usuario=$login&senha=$senha&so=$so&modelo=$modelo");
  http.Response response = await http.get("${Url}?op=$operacao$Requis");
  dynamic erro;
  print(response.body);
  try {
    dadosProativaGo = jsonDecode(response.body);
    print(" **** ****** **** **** Resultado = ${dadosProativaGo['erro']}");
    print(dadosProativaGo);
  } catch (e) {
    erro = jsonDecode(response.body);
    dadosProativaGo = erro[0];
    print(" **** ****** **** **** Resultado = ${dadosProativaGo['erro']}");
    print(dadosProativaGo);
  }
  // dadosProativaGo = jsonDecode(response.body);
  //print(" **** ****** **** **** Resultado = ${dadosProativaGo['erro']}");
  print(dadosProativaGo);
  return dadosProativaGo['erro'];
}

//Le e escreve dados texto no dispositivo

//Abre arquivo
/*Future<File> getPreferencia() async {
  */ /*import 'dart:io' as io;
// for a file
  io.File(path).exists();
// for a directory
  io.Directory(path).exists();*/ /*
  final directory = await getApplicationDocumentsDirectory();
  return File("${directory.path}/preferencias.json" );
}
//Salva dados string
Future<File> salvaPreferencia() async {
  String data = json.encode(preferencias);

  final file = await getPreferencia();
  return file.writeAsString(data);
}*/
//Ledados string
/*Future<String> lePreferencia() async {
  try {
    final file = await getPreferencia();
    return file.readAsString();
  } catch (e) {
    return null;
  }
}*/

alerta(BuildContext context, String texto, {Icon icone}) {
  Widget mensagem;
  if (icone != null) {
    mensagem = Column(
      children: [icone, Text(texto)],
    );
  } else {
    mensagem = Text(texto);
  }
  showDialog(
      context: context,
      builder: (context) => AlertDialog(
            title: mensagem,
            actions: [
              ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text('ok'))
            ],
          ));
}
