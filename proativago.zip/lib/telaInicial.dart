import 'package:flutter/material.dart';
import 'dados.dart';
class telaInicial extends StatefulWidget {
  @override
  _telaInicialState createState() => _telaInicialState();
}

class _telaInicialState extends State<telaInicial> {
  String banco = "Protiva conexão: Valores Recebidos \n"
      "status:${dadosProativaGo['status']}\n"
      "resp:${dadosProativaGo['resp']}\n"
      "idequipamento:${dadosProativaGo['idequipamento']}\n"
      "usuario:${dadosProativaGo['usuario']}\n"
      "idempresa:${dadosProativaGo['idempresa']}\n"
      "razao_social:${dadosProativaGo['razao_social']}\n"
      "nome_fantasia:${dadosProativaGo['nome_fantasia']}\n"
      "departamento:${dadosProativaGo['departamento']}\n"
      "turma:${dadosProativaGo['turma']}\n"
      "admin:${dadosProativaGo['admin']}\n"
      "gestor:${dadosProativaGo['gestor']}\n"
      "gestorturma:${dadosProativaGo['gestorturma']}\n"
      "conexao:${dadosProativaGo['conexao']}\n";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Logado! (Em Desenvolvimento!)"),
        ),
        body: Container(child:
          Center(
            child: Container(
              width: menorTamanho*0.8,
              height: menorTamanho*0.8,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [

                  Text(banco),
                  Icon(Icons.build,size: 35,)],
              ),
            ),
          ),));
  }
}
