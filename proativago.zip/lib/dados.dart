
import 'package:flutter/material.dart';
//import 'dart:async';

String Url = "https://www.imerysproativo.com/proativogo/webservice/requisicao.php";
String login ="cesarxavier66@gmail.com";
String senha= "Jo2JWzcx";
String so="android";
String modelo = "modelo";
//operadores
String operLogin="LOGIN";

//INTERFACE
String plataforma ;
bool isTemaDark = false;
double altura;
double largura;
double densidadeH;
double menorTamanho;

bool gravarSenha = false;

//Mapas de requisição
Map<String,dynamic> mapaLogin= {
  "usuario":login,
  "senha":senha,
  "so":so,
  "modelo":modelo
};
List ops=["LOGIN","NOVAFICHA","ANALISE","ANALISEEXC",
          "PLANOACAO","EFICACIA","FICHALISTA","ACAONOVA",
          "ACAAOALTERA","PEGAACOES","EMPRESA","LOCALIZACAO",
          "CLASSIFICACAO"];
Map<String,dynamic> dadosProativaGo;

/*
Future<String> getDadosProativaGo() async{
  http.Response response = await http.get("${Url}?op=LOGIN&usuario=$login&senha=$senha"
      "&so=$so&modelo=$modelo");
  print(response.body);
  dadosProativaGo = jsonDecode(response.body);
  return dadosProativaGo['erro'];
}
*/

/*
Future<Map> getDadosProativaGo() async{
  http.Response response = await http.get("${Url}?op=LOGIN&usuario=$login&senha=$senha"
      "&so=$so&modelo=$modelo");
  print(response.body);
  dadosProativaGo = jsonDecode(response.body);
  return dadosProativaGo;
}*/
