package br.com.xaviertec.proativago

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
